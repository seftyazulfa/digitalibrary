<?php 
$koneksi = mysqli_connect("localhost","seftyaa","09zlf","digitalibrary");

 
// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}
 
?>